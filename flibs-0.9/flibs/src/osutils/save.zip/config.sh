# config.sh --
#     Part of the configuration procedure for OS utils
#     Clean up and run the makefile
#
make clean
make -k
make clean
